# 硬件工作量与成本

## R — 原文与定位

> “单位工作量是一定周期内，针对某一类硬件设备的运维所需的人日数。”

来源：GB/T 28827.7—2022，7.3.3.2，印刷 p.9（PDF 第16页）。工作量与成本结构见7.2—7.3，p.8—10；其他费用见7.4—7.6，p.10—12；安全设备例外见7.1，p.8。

## I — 方法解释

硬件运维按网络、计算、存储、输入输出及外围设备等实际类别组织清单。
每类保留数量与单对象周期工作量，不把所有设备假定为同一种工时。
数量、单位工作量和最终工作量因子的乘积形成分类工作量。
分类工作量须配对本类适用的价格和价格调整因子，之后才能汇总直接人力。
硬件总成本还包含已核定的直接非人力和两类间接费用。
这些费用缺失时，可以保留已知人工小计，但不能声称全部成本已经完成。
安全设备有明确转第9章的要求，不能仅因它是实体设备就留在硬件模型。
设备运行年限、环境和人员能力用于参数取证，不自动产生统一折扣或费率。

## A1 — 合成演练

原书未提供该任务的完整案例；以下为合成演练。年度范围：A类8台，U＝0.6人日/台，Kw＝1.2，P＝900元/人日，Kp＝1.1；B类3台，U＝1.5人日/台，Kw＝1，P＝1,200元/人日，Kp＝1。上述因子均为已核定最终值。其他三类费用DN＝1,000元、IL＝600元、IN＝300元，未与单价重复。

A类W＝5.76人日，DL＝5,702.40元；B类W＝4.5人日，DL＝5,400元。总工作量10.26人日，直接人力11,102.40元；完整硬件成本13,002.40元。不能将10.26人日全部乘A类或B类价格。

## A2 — 触发场景与近邻区分

- 用户给出服务器、交换机和存储设备，要求“硬件维保成本 / hardware maintenance cost”。
- 用户有分台数、单位工时、系数和人日价，要求“逐项复算 / category cost review”。
- 不同设备类别的工时或单价不同，用户要求“为什么不能统一乘价 / matching labor rates”。
- 用户想按设备采购价格或使用年数直接套维护百分比，要求“标准能否这样估 / maintenance percentage”。

基础设施电力、空调等转 environment-cost；安全设备转 security-cost。仅有活动频次先读 unit-workload。此卡不根据设备采购额生成固定维保比例，已有费用分摊转 cost-ledger。

## E — 执行契约

**输入**：硬件类别、对象清单和服务目录；统一周期；每类数量 N、单位人日 U、最终工作量因子 Kw、适用人日价 P和最终价格因子 Kp及来源；三类其他费用DN、IL、IN与包含项；币种。

1. 核实第7章范围，安全设备转第9章。核对 N与U分别对应全体数量和单对象全周期，不能重复乘台数或次数。完成标准：类别、单位、周期无歧义。
2. 核对因子、价格和适用证据。仅有年限、SLA或人员级别名称不足以计算；将缺值转 parameter-evidence。完成标准：所有使用的最终因子有已给数值，未从附录或经验擅定。
3. 分别计算 W_i＝N_i×U_i×Kw_i、DL_i＝W_i×P_i×适用Kp。再求 W和DL的分类合计。完成标准：保留各类乘数、工作量、单价和成本，不以无依据的统一价代替分类价格。
4. 从费用台账获得 DN、IL、IN，核对已含项；齐备时 C＝DL＋DN＋IL＋IN。缺任一金额则只给明确的已知小计与待补清单，不把未知置0。完成标准：DL与C不混称。
5. 输出 `类别｜规模｜U｜Kw｜W｜P｜Kp｜DL｜来源` 及其他费用、周期、币种、完整性说明。

**精度约定**：计算保留中间精度，金额默认展示到分；用户指定的项目舍入规则优先并须写明。先读 CALCULATOR.md，以 `mode=hardware` 从技能根目录运行 `python resources/itom_calc.py input.json --out output.json`。输入真实适用性仍需人工/资料核验。

## B — 边界与关联

**来源边界**：原文未给全国统一的人日工时、设备年龄固定折扣、采购额维保率或人员系数。价格调整和工作量调整不能按同一因素名单随意各乘一次。

**实施控制**：非负数量与费用、因子有限值、量纲一致、未知项显式保留是工程校验；脚本通过不等于报价已获全部依据。

关联：scope-routing 处理类别；unit-workload 产出U；parameter-evidence 核查参数；nonhuman-cost 与 cost-ledger 补齐费用；total-review 汇总结果。

## 配套资源

路径相对于本文件；脚本需先检查运行条件，不因附带而自动执行。

- [resources/itom_calc.py](../../resources/itom_calc.py)
- [resources/CALCULATOR.md](../../resources/CALCULATOR.md)
- [resources/example-inputs.json](../../resources/example-inputs.json)
- [resources/project-template.json](../../resources/project-template.json)
- [resources/parameter-register.csv](../../resources/parameter-register.csv)
- [resources/scope-limitations.md](../../resources/scope-limitations.md)
